"""
inference.py
Evaluate trained models on test sets.

The skeleton requires:
  - parse_arguments() with specific args
  - load_model(model_path)
  - evaluate_model(model, X_test, y_test) → dict with logits, loss, accuracy, f1, precision, recall
  - main() → returns the same dict

Run example:
    python src/inference.py \
        --model_path models/best_model.npy \
        --dataset fashion_mnist
"""

import argparse
import sys
import os
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ann.neural_network import NeuralNetwork
from ann.optimizers import get_optimizer
from utils.data_loader import load_dataset, to_onehot, get_class_names
from utils.metrics import compute_metrics, get_confusion_matrix
from ann.objective_functions import get_loss
from ann.activations import softmax


# ─────────────────────────────────────────────
#  Argument Parsing (matches skeleton spec)
# ─────────────────────────────────────────────

def parse_arguments():
    """
    Parse command-line arguments for inference.
    Matches skeleton TODOs exactly:
      - model_path   : path to saved model weights (relative path)
      - dataset      : dataset to evaluate on
      - batch_size   : batch size for inference
      - hidden_layers: list of hidden layer sizes
      - num_neurons  : number of neurons in hidden layers
      - activation   : activation function
    """
    parser = argparse.ArgumentParser(description='Run inference on test set')

    # Paths (relative as required)
    parser.add_argument('--model_path', type=str, default='models/best_model.npy',
                        help='Relative path to saved model weights (.npy)')
    parser.add_argument('--config_path', type=str, default='models/best_config.json',
                        help='Relative path to model config (.json)')

    # Dataset
    parser.add_argument('-d', '--dataset', type=str, default=None,
                        choices=['mnist', 'fashion_mnist'],
                        help='Dataset override (defaults to value in config)')

    # Inference settings
    parser.add_argument('--batch_size', type=int, default=256,
                        help='Batch size for inference')
    parser.add_argument('--split', type=str, default='test',
                        choices=['test', 'val', 'train'],
                        help='Which data split to evaluate on')

    # Architecture (used if no config file found)
    parser.add_argument('--hidden_layers', type=int, nargs='+', default=None,
                        help='List of hidden layer sizes, e.g. --hidden_layers 128 128 128')
    parser.add_argument('--num_neurons', type=int, default=128,
                        help='Number of neurons in each hidden layer (if hidden_layers not given)')
    parser.add_argument('-nhl', '--num_layers', type=int, default=3,
                        help='Number of hidden layers (if hidden_layers not given)')
    parser.add_argument('-a', '--activation', type=str, default='relu',
                        choices=['relu', 'sigmoid', 'tanh'],
                        help='Activation function')
    parser.add_argument('-w_i', '--weight_init', type=str, default='xavier',
                        choices=['random', 'xavier'])
    parser.add_argument('-l', '--loss', type=str, default='cross_entropy',
                        choices=['cross_entropy', 'mse'])
    parser.add_argument('-wd', '--weight_decay', type=float, default=0.0)

    return parser.parse_args()


# ─────────────────────────────────────────────
#  Load Model
# ─────────────────────────────────────────────

def load_model(model_path, config_path=None, args=None):
    """
    Load trained model from disk.

    Args:
        model_path  : relative path to .npy weights file
        config_path : relative path to .json config file (optional)
        args        : parsed CLI args (fallback if no config file)

    Returns:
        model: NeuralNetwork instance with weights loaded
        config: dict of model configuration
    """
    # Try loading config file first
    config = None
    if config_path and os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = json.load(f)
        print(f"[INFO] Config loaded from {config_path}")
    else:
        print("[WARN] No config file found. Using CLI arguments.")

    # Build args namespace for NeuralNetwork
    import argparse
    model_args = argparse.Namespace()

    if config:
        model_args.num_layers   = len(config['hidden_sizes'])
        model_args.hidden_size  = config['hidden_sizes']
        model_args.activation   = config['activation']
        model_args.weight_init  = config['weight_init']
        model_args.loss         = config['loss']
        model_args.weight_decay = config.get('weight_decay', 0.0)
    else:
        # Fallback to CLI args
        if args.hidden_layers:
            model_args.hidden_size = args.hidden_layers
            model_args.num_layers  = len(args.hidden_layers)
        else:
            model_args.num_layers  = args.num_layers
            model_args.hidden_size = [args.num_neurons] * args.num_layers
        model_args.activation   = args.activation
        model_args.weight_init  = args.weight_init
        model_args.loss         = args.loss
        model_args.weight_decay = args.weight_decay
        config = {}

    model = NeuralNetwork(cli_args=model_args)
    model.load_weights(model_path)
    print(f"[INFO] Weights loaded from {model_path}")

    return model, config


# ─────────────────────────────────────────────
#  Evaluate Model
# ─────────────────────────────────────────────

def evaluate_model(model, X_test, y_test):
    """
    Evaluate model on test data.

    Args:
        model  : NeuralNetwork instance
        X_test : inputs,  shape (N, 784)
        y_test : labels,  shape (N,) integer class indices

    Returns:
        Dictionary with keys:
          logits    : raw network output logits, shape (N, 10)
          loss      : scalar loss value
          accuracy  : fraction of correct predictions
          f1        : macro F1 score
          precision : macro precision
          recall    : macro recall
    """
    y_onehot = to_onehot(y_test)

    # Run forward pass
    logits = model.forward(X_test)

    # Compute loss
    loss_fn = model.loss_fn
    loss, _ = loss_fn(logits, y_onehot)

    # Compute predictions
    predictions = np.argmax(logits, axis=1)

    # Compute metrics
    metrics = compute_metrics(y_test, predictions)

    return {
        'logits':    logits,
        'loss':      float(loss),
        'accuracy':  metrics['accuracy'],
        'f1':        metrics['f1'],
        'precision': metrics['precision'],
        'recall':    metrics['recall'],
    }


def to_onehot(y, num_classes=10):
    """Convert integer labels to one-hot. Defined here for standalone use."""
    oh = np.zeros((len(y), num_classes), dtype=np.float32)
    oh[np.arange(len(y)), y] = 1.0
    return oh


# ─────────────────────────────────────────────
#  Main
# ─────────────────────────────────────────────

def main():
    """
    Main inference function.
    Returns Dictionary: logits, loss, accuracy, f1, precision, recall
    """
    args = parse_arguments()

    # ── Load model ──
    model, config = load_model(
        model_path=args.model_path,
        config_path=args.config_path,
        args=args
    )

    # ── Decide dataset ──
    dataset_name = args.dataset or config.get('dataset', 'fashion_mnist')

    # ── Load data ──
    X_train, y_train, X_val, y_val, X_test, y_test = load_dataset(dataset_name)

    split_map = {'test': (X_test, y_test), 'val': (X_val, y_val), 'train': (X_train, y_train)}
    X_eval, y_eval = split_map[args.split]

    print(f"\n[INFO] Evaluating on '{args.split}' split: {X_eval.shape[0]} samples")

    # ── Evaluate ──
    results = evaluate_model(model, X_eval, y_eval)

    # ── Print results ──
    print("\n" + "="*50)
    print("         INFERENCE RESULTS")
    print("="*50)
    print(f"  Accuracy  : {results['accuracy']:.4f}  ({results['accuracy']*100:.2f}%)")
    print(f"  Precision : {results['precision']:.4f}")
    print(f"  Recall    : {results['recall']:.4f}")
    print(f"  F1-Score  : {results['f1']:.4f}")
    print(f"  Loss      : {results['loss']:.4f}")
    print("="*50)

    # ── Per-class breakdown ──
    predictions  = np.argmax(results['logits'], axis=1)
    class_names  = get_class_names(dataset_name)
    cm = get_confusion_matrix(y_eval, predictions)

    print("\nPer-Class Accuracy:")
    for i, name in enumerate(class_names):
        mask      = y_eval == i
        class_acc = float(np.mean(predictions[mask] == y_eval[mask]))
        print(f"  Class {i:2d} ({name:15s}): {class_acc:.4f}")

    print("\nEvaluation complete!")
    return results


if __name__ == '__main__':
    main()
