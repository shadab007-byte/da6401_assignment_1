"""
optimizers.py
All 6 optimizers required by the assignment.
Each has an update(layers) method that modifies layer.W and layer.b in-place.
"""

import numpy as np


class SGD:
    """Vanilla SGD: W = W - lr * grad_W"""

    def __init__(self, learning_rate=0.01, weight_decay=0.0, **kwargs):
        self.lr = learning_rate
        self.wd = weight_decay

    def update(self, layers):
        for layer in layers:
            layer.W -= self.lr * layer.grad_W
            layer.b -= self.lr * layer.grad_b


class Momentum:
    """
    SGD + Momentum. Accumulates velocity to speed up learning.
    v  = beta*v - lr*grad
    W  = W + v
    """

    def __init__(self, learning_rate=0.01, beta=0.9, weight_decay=0.0, **kwargs):
        self.lr   = learning_rate
        self.beta = beta
        self.wd   = weight_decay

    def update(self, layers):
        for layer in layers:
            layer.v_W = self.beta * layer.v_W - self.lr * layer.grad_W
            layer.v_b = self.beta * layer.v_b - self.lr * layer.grad_b
            layer.W  += layer.v_W
            layer.b  += layer.v_b


class NAG:
    """
    Nesterov Accelerated Gradient.
    Looks ahead before computing gradient → better convergence than Momentum.
    """

    def __init__(self, learning_rate=0.01, beta=0.9, weight_decay=0.0, **kwargs):
        self.lr   = learning_rate
        self.beta = beta
        self.wd   = weight_decay

    def update(self, layers):
        for layer in layers:
            v_W_prev = layer.v_W.copy()
            v_b_prev = layer.v_b.copy()

            layer.v_W = self.beta * layer.v_W - self.lr * layer.grad_W
            layer.v_b = self.beta * layer.v_b - self.lr * layer.grad_b

            # Nesterov correction
            layer.W += -self.beta * v_W_prev + (1 + self.beta) * layer.v_W
            layer.b += -self.beta * v_b_prev + (1 + self.beta) * layer.v_b


class RMSProp:
    """
    RMSProp: adapts learning rate by dividing by running mean of squared gradients.
    v  = beta*v + (1-beta)*grad^2
    W  = W - lr / sqrt(v + eps) * grad
    """

    def __init__(self, learning_rate=0.001, beta=0.9, eps=1e-8, weight_decay=0.0, **kwargs):
        self.lr   = learning_rate
        self.beta = beta
        self.eps  = eps
        self.wd   = weight_decay

    def update(self, layers):
        for layer in layers:
            layer.m_W = self.beta * layer.m_W + (1 - self.beta) * layer.grad_W ** 2
            layer.m_b = self.beta * layer.m_b + (1 - self.beta) * layer.grad_b ** 2
            layer.W  -= self.lr * layer.grad_W / (np.sqrt(layer.m_W) + self.eps)
            layer.b  -= self.lr * layer.grad_b / (np.sqrt(layer.m_b) + self.eps)


class Adam:
    """
    Adam: Combines Momentum (1st moment) + RMSProp (2nd moment) + bias correction.
    Best general-purpose optimizer.
    """

    def __init__(self, learning_rate=0.001, beta1=0.9, beta2=0.999, eps=1e-8,
                 weight_decay=0.0, **kwargs):
        self.lr    = learning_rate
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps   = eps
        self.wd    = weight_decay
        self.t     = 0  # timestep for bias correction

    def update(self, layers):
        self.t += 1
        bc1 = 1 - self.beta1 ** self.t
        bc2 = 1 - self.beta2 ** self.t

        for layer in layers:
            # 1st moment (momentum-like)
            layer.v_W = self.beta1 * layer.v_W + (1 - self.beta1) * layer.grad_W
            layer.v_b = self.beta1 * layer.v_b + (1 - self.beta1) * layer.grad_b
            # 2nd moment (RMSProp-like)
            layer.m_W = self.beta2 * layer.m_W + (1 - self.beta2) * layer.grad_W ** 2
            layer.m_b = self.beta2 * layer.m_b + (1 - self.beta2) * layer.grad_b ** 2
            # Bias-corrected
            v_W_hat = layer.v_W / bc1
            v_b_hat = layer.v_b / bc1
            m_W_hat = layer.m_W / bc2
            m_b_hat = layer.m_b / bc2

            layer.W -= self.lr * v_W_hat / (np.sqrt(m_W_hat) + self.eps)
            layer.b -= self.lr * v_b_hat / (np.sqrt(m_b_hat) + self.eps)


class Nadam:
    """
    Nadam: Nesterov + Adam. Uses lookahead on 1st moment.
    Slightly better than Adam in many tasks.
    """

    def __init__(self, learning_rate=0.001, beta1=0.9, beta2=0.999, eps=1e-8,
                 weight_decay=0.0, **kwargs):
        self.lr    = learning_rate
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps   = eps
        self.wd    = weight_decay
        self.t     = 0

    def update(self, layers):
        self.t += 1
        bc1 = 1 - self.beta1 ** self.t
        bc2 = 1 - self.beta2 ** self.t

        for layer in layers:
            layer.v_W = self.beta1 * layer.v_W + (1 - self.beta1) * layer.grad_W
            layer.v_b = self.beta1 * layer.v_b + (1 - self.beta1) * layer.grad_b
            layer.m_W = self.beta2 * layer.m_W + (1 - self.beta2) * layer.grad_W ** 2
            layer.m_b = self.beta2 * layer.m_b + (1 - self.beta2) * layer.grad_b ** 2

            m_W_hat = layer.m_W / bc2
            m_b_hat = layer.m_b / bc2

            # Nesterov: use lookahead on 1st moment
            nW = (self.beta1 * layer.v_W / bc1) + ((1 - self.beta1) * layer.grad_W / bc1)
            nb = (self.beta1 * layer.v_b / bc1) + ((1 - self.beta1) * layer.grad_b / bc1)

            layer.W -= self.lr * nW / (np.sqrt(m_W_hat) + self.eps)
            layer.b -= self.lr * nb / (np.sqrt(m_b_hat) + self.eps)


OPTIMIZERS = {
    "sgd":      SGD,
    "momentum": Momentum,
    "nag":      NAG,
    "rmsprop":  RMSProp,
    "adam":     Adam,
    "nadam":    Nadam,
}


def get_optimizer(name, **kwargs):
    """Return instantiated optimizer by string name."""
    name = name.lower()
    if name not in OPTIMIZERS:
        raise ValueError(f"Unknown optimizer '{name}'. Choose: {list(OPTIMIZERS.keys())}")
    return OPTIMIZERS[name](**kwargs)
