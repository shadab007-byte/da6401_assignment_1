"""
activations.py
Activation functions and their derivatives used in the MLP.
"""

import numpy as np


def sigmoid(z):
    """Sigmoid: maps any value to (0,1). Formula: 1 / (1 + e^-z)"""
    z = np.clip(z, -500, 500)  # prevent overflow
    return 1.0 / (1.0 + np.exp(-z))


def sigmoid_derivative(z):
    """Derivative of sigmoid w.r.t. pre-activation z."""
    s = sigmoid(z)
    return s * (1.0 - s)


def tanh(z):
    """Tanh: maps any value to (-1,1). Better than sigmoid for hidden layers."""
    return np.tanh(z)


def tanh_derivative(z):
    """Derivative of tanh w.r.t. pre-activation z."""
    return 1.0 - np.tanh(z) ** 2


def relu(z):
    """ReLU: max(0, z). Most popular activation for hidden layers."""
    return np.maximum(0, z)


def relu_derivative(z):
    """Derivative of ReLU: 1 where z>0, else 0."""
    return (z > 0).astype(float)


def softmax(z):
    """
    Softmax for output layer. Converts logits to probabilities summing to 1.
    Subtracts max per row for numerical stability.
    """
    z_stable = z - np.max(z, axis=1, keepdims=True)
    exp_z = np.exp(z_stable)
    return exp_z / np.sum(exp_z, axis=1, keepdims=True)


# Easy lookup by string name
ACTIVATIONS = {
    "sigmoid": (sigmoid, sigmoid_derivative),
    "tanh":    (tanh,    tanh_derivative),
    "relu":    (relu,    relu_derivative),
}


def get_activation(name):
    """Returns (activation_fn, derivative_fn) tuple by name string."""
    name = name.lower()
    if name not in ACTIVATIONS:
        raise ValueError(f"Unknown activation '{name}'. Choose: {list(ACTIVATIONS.keys())}")
    return ACTIVATIONS[name]
