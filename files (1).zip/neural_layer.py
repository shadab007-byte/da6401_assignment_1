"""
neural_layer.py
A single fully-connected (dense) layer of the MLP.
Stores weights, biases, and their gradients (self.grad_W, self.grad_b).
The autograder checks self.grad_W and self.grad_b after backward().
"""

import numpy as np
from .activations import get_activation, softmax


class Layer:
    """
    One dense layer. Contains:
      W        : weight matrix shape (input_size, output_size)
      b        : bias vector  shape (1, output_size)
      grad_W   : gradient of loss w.r.t. W  -- autograder checks this!
      grad_b   : gradient of loss w.r.t. b  -- autograder checks this!
    """

    def __init__(self, input_size, output_size, activation="relu", weight_init="xavier"):
        """
        Args:
            input_size  (int): number of inputs to this layer
            output_size (int): number of neurons in this layer
            activation  (str): 'sigmoid', 'tanh', 'relu', or 'softmax'
            weight_init (str): 'random' or 'xavier'
        """
        self.input_size  = input_size
        self.output_size = output_size
        self.activation_name = activation

        # ── Weight Initialization ──
        if weight_init == "xavier":
            # Xavier: weights sampled from uniform[-limit, limit]
            # Designed to keep variance stable across layers
            limit = np.sqrt(6.0 / (input_size + output_size))
            self.W = np.random.uniform(-limit, limit, (input_size, output_size))
        elif weight_init == "random":
            self.W = np.random.randn(input_size, output_size) * 0.01
        else:
            raise ValueError(f"Unknown weight_init '{weight_init}'. Use 'random' or 'xavier'.")

        self.b = np.zeros((1, output_size))  # biases start at 0

        # ── Activation Function ──
        if activation == "softmax":
            self.activation_fn    = softmax
            self.activation_deriv = None  # handled at loss level
        else:
            self.activation_fn, self.activation_deriv = get_activation(activation)

        # ── Forward pass cache (filled by forward()) ──
        self.input = None   # input  coming into this layer
        self.z     = None   # pre-activation  (W*input + b)
        self.a     = None   # post-activation (activation(z))

        # ── Gradients (filled by backward(), checked by autograder) ──
        self.grad_W = np.zeros_like(self.W)
        self.grad_b = np.zeros_like(self.b)

        # ── Optimizer state (used by Adam, RMSProp, Momentum etc.) ──
        self.v_W = np.zeros_like(self.W)   # velocity / 1st moment
        self.v_b = np.zeros_like(self.b)
        self.m_W = np.zeros_like(self.W)   # 2nd moment (Adam/RMSProp)
        self.m_b = np.zeros_like(self.b)

    def forward(self, a_prev):
        """
        Forward pass: z = a_prev @ W + b,  a = activation(z)

        Args:
            a_prev: array shape (batch_size, input_size)
        Returns:
            a:      array shape (batch_size, output_size)
        """
        self.input = a_prev
        self.z = a_prev @ self.W + self.b
        self.a = self.activation_fn(self.z)
        return self.a

    def backward(self, delta, weight_decay=0.0):
        """
        Backward pass: compute grad_W, grad_b and return delta for previous layer.

        Args:
            delta        : gradient from next layer, shape (batch_size, output_size)
            weight_decay : L2 regularization lambda
        Returns:
            delta_prev: gradient to pass back, shape (batch_size, input_size)
        """
        batch_size = self.input.shape[0]

        # Gradient w.r.t. W (averaged over batch) + L2 penalty
        self.grad_W = (self.input.T @ delta) / batch_size + weight_decay * self.W

        # Gradient w.r.t. b (averaged over batch)
        self.grad_b = np.sum(delta, axis=0, keepdims=True) / batch_size

        # Pass gradient to previous layer
        delta_prev = delta @ self.W.T
        return delta_prev
